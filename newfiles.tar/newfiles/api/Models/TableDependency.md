# TableDependency
## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
| **table\_full\_name** | **String** | Full name of the dependent table, in the form of __catalog_name__.__schema_name__.__table_name__. | [default to null] |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

